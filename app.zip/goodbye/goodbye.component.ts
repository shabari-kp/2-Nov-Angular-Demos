import { Component } from '@angular/core';

@Component({
  selector: 'app-goodbye',
  templateUrl: './goodbye.component.html',
  styleUrls: ['./goodbye.component.css']
})
export class GoodbyeComponent {
 
  msg:string="sdklfjsldjfsljdflsjkdf";

  sayGoodbye()
  {
    alert ("bye");
  }
   
}
