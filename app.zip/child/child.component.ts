import { Component, Input,EventEmitter,Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent 
{
   @Input() result:number=0;

 //create the custom event
 //sending the event outside the cmp
 
  @Output() notify=new EventEmitter<string>();

 triggerEvent()
 {
    this.notify.emit("hi from child");
    
 }

}
