
import {Component} from '@angular/core';

@Component({
    
   // templateUrl:'', // attach the html 
   // styleUrls:'' //attach css
   selector:'my-samp-date-cmp',
   template: `<p> date is {{result}} </p>`,
 //styles:''
})
export class DisplayDate
{
    result:string;
    constructor()
    {
        var d=new Date(); //date is a predefined obj in js
    this.result=d.toString();

    }
}