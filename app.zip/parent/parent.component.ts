import { Component } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent 
{
   rnd:number=0;
   msg:string="";

   generateRandom()
   {
      this.rnd=Math.random(); //js 
   }

   GetDatafromChild(str:string) {
 this.msg=str;

   }
 

}
